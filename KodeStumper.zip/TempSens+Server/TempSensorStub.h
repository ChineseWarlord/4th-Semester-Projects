//TempSensorStub.h
#ifndef TEMP_SENSOR_STUB
#define TEMP_SENSOR_STUB

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>

void* TempGen(void* arg);

#endif