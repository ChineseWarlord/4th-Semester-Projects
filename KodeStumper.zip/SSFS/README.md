SSFS

"Simple Stupid FileSystem"